# Run as Administrator
# This creates a port proxy for WebSocket connections

Write-Host "=== Setting up Port Forwarding for WebSocket ===" -ForegroundColor Cyan

# Remove existing port proxy if any
netsh interface portproxy delete v4tov4 listenport=8081 listenaddress=0.0.0.0

# Add port proxy: External 8081 -> Internal 8080
netsh interface portproxy add v4tov4 listenport=8081 listenaddress=0.0.0.0 connectport=8080 connectaddress=127.0.0.1

# Show current port proxies
Write-Host "`nCurrent Port Proxies:" -ForegroundColor Yellow
netsh interface portproxy show all

# Add firewall rule
$firewallRule = Get-NetFirewallRule -DisplayName "WebSocket Port 8081" -ErrorAction SilentlyContinue
if ($null -eq $firewallRule) {
    New-NetFirewallRule -DisplayName "WebSocket Port 8081" -Direction Inbound -LocalPort 8081 -Protocol TCP -Action Allow
    Write-Host "`nFirewall rule created for port 8081" -ForegroundColor Green
} else {
    Write-Host "`nFirewall rule already exists for port 8081" -ForegroundColor Green
}

Write-Host "`n=== Setup Complete ===" -ForegroundColor Cyan
Write-Host "WebSocket endpoint: ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/websocket/logs" -ForegroundColor White
Write-Host "Remember to open port 8081 in Azure NSG!" -ForegroundColor Yellow
