# WebSocket Configuration Complete ✅

## Azure Resources
- **VM Name**: GCCH-JS-TEST
- **Resource Group**: GCCH-JS-TEST_group
- **Subscription ID**: 50ad1522-5c2c-4d9a-a6c8-67c11ecb75b8
- **Public DNS**: gcch-js-test-nk.eastus.cloudapp.azure.com

## Application Configuration Summary

### Ports Configuration:
- **Port 8080**: HTTPS with SSL certificate (for `wss://` secure WebSocket)
- **Port 8081**: HTTP (for `ws://` non-secure WebSocket)
- **Port 443**: IIS HTTPS (proxies to port 8081)
- **Port 80**: IIS HTTP (proxies to port 8081)

### SSL Certificate:
- **Type**: Self-signed certificate
- **Location**: `src/main/resources/keystore.p12`
- **Format**: PKCS12
- **Alias**: tomcat
- **CN**: gcch-js-test-nk.eastus.cloudapp.azure.com
- **Validity**: 3650 days

---

## ✅ Step 1: Open Required Ports in Azure NSG

### Port 8080 (HTTPS/WSS - Required for secure WebSocket)

**Azure Portal:**
1. Go to: https://portal.azure.com
2. Navigate to: **Virtual Machines** → **GCCH-JS-TEST**
3. Click: **Networking** (left menu) → **Network settings**
4. Click: **Create port rule** → **Inbound port rule**
5. Configure:
   - **Source**: Any
   - **Source port ranges**: *
   - **Destination**: Any
   - **Service**: Custom
   - **Destination port ranges**: **8080**
   - **Protocol**: TCP
   - **Action**: Allow
   - **Priority**: 111
   - **Name**: WebSocket-SSL-8080
6. Click: **Add**

**Azure CLI:**
```bash
az network nsg rule create \
  --resource-group GCCH-JS-TEST_group \
  --nsg-name GCCH-JS-TEST-nsg \
  --name WebSocket-SSL-8080 \
  --priority 111 \
  --destination-port-ranges 8080 \
  --protocol Tcp \
  --access Allow \
  --direction Inbound
```

### Port 8081 (HTTP/WS - Already open, verified ✅)

**Note**: Port 8081 is already open and verified working.

---

## ✅ Step 2: Accept Self-Signed SSL Certificate (One-time)

**For WSS (Secure WebSocket) connections, you must first accept the self-signed certificate:**

1. Open in browser: **https://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/**
2. You'll see: "Your connection is not private" or "NET::ERR_CERT_AUTHORITY_INVALID"
3. Click: **"Advanced"** or **"Show Details"**
4. Click: **"Proceed to site"** or **"Continue to gcch-js-test-nk.eastus.cloudapp.azure.com (unsafe)"**
5. You should see a blank page or 404 error (that's fine!)
6. Certificate is now trusted for this browser session

**Note**: This is a one-time step per browser. For production, replace with a CA-signed certificate.

---

## ✅ Step 3: WebSocket Connection Options

### Option A: Via IIS Proxy (Recommended for production)
Access logs.html through IIS:
- **URL**: `https://gcch-js-test-nk.eastus.cloudapp.azure.com/logs.html`
- **WebSocket**: Automatically uses `ws://` via IIS proxy to port 8081
- **Pros**: Standard HTTPS URL, no port numbers needed
- **Cons**: IIS ARR has WebSocket limitations

### Option B: Direct HTTP Connection (Port 8081)
Access logs.html directly:
- **URL**: `http://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/logs.html`
- **WebSocket**: `ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/websocket/logs`
- **Pros**: Bypasses IIS, more reliable WebSocket
- **Cons**: Non-secure HTTP, requires port number

### Option C: Direct HTTPS Connection (Port 8080) - Best Performance
Access logs.html directly with SSL:
- **URL**: `https://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/logs.html`
- **WebSocket**: `wss://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/websocket/logs`
- **Pros**: Secure, direct to Java app, best performance, no IIS overhead
- **Cons**: Requires certificate acceptance, port number in URL

### All Available WebSocket Endpoints:
- `ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/websocket/logs` ✅
- `wss://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/websocket/logs` ✅
- `ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/ws/logs` ✅
- `wss://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/ws/logs` ✅
- `ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/logs/ws` ✅
- `wss://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/logs/ws` ✅

---

## Configuration Summary

### What Was Done:
1. ✅ **Generated self-signed SSL certificate** (keystore.p12)
2. ✅ **Configured dual-protocol support** in Spring Boot:
   - Port 8080: HTTPS (with SSL certificate)
   - Port 8081: HTTP (for backward compatibility)
3. ✅ **Updated IIS web.config** to proxy to port 8081
4. ✅ **Opened Windows Firewall** for ports 8080 and 8081
5. ✅ **Verified local connectivity** on both ports
6. ✅ **Verified Azure NSG** - port 8081 already open
7. ⏳ **Pending**: Open Azure NSG for port 8080 (for direct WSS connections)

### Why Dual-Protocol Configuration:
- **IIS ARR has limited WebSocket support** - connections can be unstable
- **Port 8081 (HTTP)** - For IIS proxy and non-secure connections
- **Port 8080 (HTTPS)** - For direct secure WebSocket (WSS) connections
- **Flexibility** - Users can choose between IIS proxy or direct connection

### Architecture:
```
Option 1: Via IIS Proxy (Current Default)
    Client Browser → HTTPS/443 (IIS)
         ↓
    IIS web.config proxy rules
         ↓
    ws://127.0.0.1:8081/websocket/logs
         ↓
    Java Spring Boot (HTTP on 8081)

Option 2: Direct HTTP (Port 8081)
    Client Browser → ws://domain:8081/websocket/logs
         ↓
    Java Spring Boot (HTTP on 8081)

Option 3: Direct HTTPS/WSS (Port 8080) - Best Performance
    Client Browser → wss://domain:8080/websocket/logs
         ↓
    Java Spring Boot (HTTPS on 8080 with SSL)
```

---

## Testing WebSocket Connections

### Test Port Connectivity:
```powershell
# Test HTTP port
Test-NetConnection -ComputerName gcch-js-test-nk.eastus.cloudapp.azure.com -Port 8081

# Test HTTPS port (after opening NSG)
Test-NetConnection -ComputerName gcch-js-test-nk.eastus.cloudapp.azure.com -Port 8080
```

### Test WebSocket in Browser Console (F12):
```javascript
// Test HTTP WebSocket (Port 8081)
const ws1 = new WebSocket('ws://gcch-js-test-nk.eastus.cloudapp.azure.com:8081/websocket/logs');
ws1.onopen = () => console.log('✅ WS Connected!');
ws1.onmessage = (e) => console.log('Message:', e.data);
ws1.onerror = (e) => console.error('❌ Error:', e);
ws1.onclose = (e) => console.log('Closed:', e.code, e.reason);

// Test HTTPS WebSocket (Port 8080) - after accepting certificate
const ws2 = new WebSocket('wss://gcch-js-test-nk.eastus.cloudapp.azure.com:8080/websocket/logs');
ws2.onopen = () => console.log('✅ WSS Connected!');
ws2.onmessage = (e) => console.log('Message:', e.data);
ws2.onerror = (e) => console.error('❌ Error:', e);
ws2.onclose = (e) => console.log('Closed:', e.code, e.reason);
```

### Using logs.html Viewer:
1. Access: `https://gcch-js-test-nk.eastus.cloudapp.azure.com/logs.html`
2. Use the dropdown to select protocol:
   - **"Auto (ws/wss)"** - Detects HTTP vs HTTPS page automatically
   - **"Force ws://"** - Always uses port 8081 (HTTP)
   - **"Force wss://"** - Always uses port 8080 (HTTPS) - requires certificate acceptance
3. Click **"Connect"** button
4. Follow on-screen instructions if certificate needs to be accepted

---

## Troubleshooting

### Error: "NET::ERR_CERT_AUTHORITY_INVALID"
**Solution**: Accept the self-signed certificate (see Step 2 above)

### Error: "WebSocket closed with code: 1006"
**Possible causes**:
1. Certificate not accepted (for wss://)
2. Azure NSG port not open
3. Windows Firewall blocking the port
4. Application not running

**Check application status**:
```powershell
# Check if Java is running
Get-Process -Name java

# Check if ports are listening
netstat -ano | findstr ":8080 :8081"
```

### Error: "Bad Request - This combination of host and port requires TLS"
**Solution**: Already fixed! This was caused by IIS trying to proxy to port 8080 (HTTPS). Now IIS proxies to port 8081 (HTTP).

### Application Won't Start - Port Already in Use
**Solution**:
```powershell
# Stop all Java processes
Stop-Process -Name java -Force

# Wait a moment
Start-Sleep -Seconds 2

# Restart the application
mvn spring-boot:run
```

---

## Production Considerations

### Replace Self-Signed Certificate:
For production, obtain a CA-signed certificate:

**Option 1: Let's Encrypt (Free)**
```bash
# Install Certbot
# Follow: https://letsencrypt.org/getting-started/

# Generate certificate
certbot certonly --standalone -d gcch-js-test-nk.eastus.cloudapp.azure.com

# Convert to PKCS12
openssl pkcs12 -export \
  -in /etc/letsencrypt/live/gcch-js-test-nk.eastus.cloudapp.azure.com/fullchain.pem \
  -inkey /etc/letsencrypt/live/gcch-js-test-nk.eastus.cloudapp.azure.com/privkey.pem \
  -out keystore.p12 \
  -name tomcat
```

**Option 2: Azure Key Vault**
Store certificates in Azure Key Vault and configure Spring Boot to load from there.

**Option 3: Commercial CA**
Purchase from DigiCert, GlobalSign, etc., and import into keystore.

### Update application.yml:
```yaml
server:
  ssl:
    key-store: classpath:keystore.p12  # or file:/path/to/keystore.p12
    key-store-password: your-password
    key-store-type: PKCS12
    key-alias: tomcat
```

---

## Files Modified

- ✅ `src/main/resources/application.yml` - Added SSL configuration
- ✅ `src/main/java/.../config/DualProtocolConfig.java` - Added dual-protocol support
- ✅ `src/main/resources/keystore.p12` - Self-signed SSL certificate
- ✅ `web.config` - Updated IIS proxy to use port 8081
- ✅ `static/logs.html` - Added protocol selection and certificate instructions
- ✅ Windows Firewall - Opened ports 8080 and 8081
- ✅ `WEBSOCKET_SETUP.md` - This documentation file
