package com.communication.callautomation.config;

import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

/**
 * Configuration to support both HTTP (ws://) and HTTPS (wss://) WebSocket connections
 * This allows the Java application to work with both secure and insecure WebSocket clients
 */
@Configuration
public class DualProtocolConfig {

    private static final Logger logger = Logger.getLogger(DualProtocolConfig.class.getName());

    @Value("${ssl.enabled:false}")
    private boolean sslEnabled;

    @Value("${ssl.port:8443}")
    private int sslPort;

    /**
     * Adds an additional HTTP connector on port 8081 when SSL is enabled on main port
     * This allows the app to listen on both HTTPS (8443) and HTTP (8081) simultaneously
     */
    @Component
    public class TomcatDualProtocolCustomizer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

        @Override
        public void customize(TomcatServletWebServerFactory factory) {
            if (sslEnabled) {
                logger.info("SSL is enabled - Main server will use HTTPS on port 8080");
                logger.info("Adding additional HTTP connector on port 8081 for non-SSL connections");
                
                // Add HTTP connector on port 8081 for ws:// connections
                Connector httpConnector = new Connector(TomcatServletWebServerFactory.DEFAULT_PROTOCOL);
                httpConnector.setScheme("http");
                httpConnector.setPort(8081);
                httpConnector.setSecure(false);
                httpConnector.setRedirectPort(8443);
                
                factory.addAdditionalTomcatConnectors(httpConnector);
                
                logger.info("Configured dual protocol support:");
                logger.info("  - HTTPS (wss://) on port 8080 (main, with SSL)");
                logger.info("  - HTTP (ws://)   on port 8081 (additional)");
            } else {
                logger.info("Running in HTTP-only mode (ws://) on port 8080");
                logger.info("SSL is handled by IIS reverse proxy for wss:// connections");
            }
        }
    }
}
