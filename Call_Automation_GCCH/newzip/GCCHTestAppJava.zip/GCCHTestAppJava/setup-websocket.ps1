# Run this script as Administrator to configure IIS for WebSocket support

Write-Host "=== IIS WebSocket Configuration Script ===" -ForegroundColor Cyan

# 1. Install required IIS features
Write-Host "`n[1/5] Installing IIS WebSocket Protocol..." -ForegroundColor Yellow
$wsFeature = Get-WindowsFeature -Name Web-WebSockets
if (-not $wsFeature.Installed) {
    Install-WindowsFeature -Name Web-WebSockets
    Write-Host "WebSocket Protocol installed" -ForegroundColor Green
} else {
    Write-Host "WebSocket Protocol already installed" -ForegroundColor Green
}

# 2. Install Application Request Routing (ARR)
Write-Host "`n[2/5] Checking Application Request Routing..." -ForegroundColor Yellow
$arrInstalled = Get-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "enabled" -ErrorAction SilentlyContinue
if ($null -eq $arrInstalled) {
    Write-Host "ARR NOT installed. Please install it manually from:" -ForegroundColor Red
    Write-Host "https://www.iis.net/downloads/microsoft/application-request-routing" -ForegroundColor Cyan
    Write-Host "Then run this script again." -ForegroundColor Yellow
} else {
    Write-Host "ARR is installed" -ForegroundColor Green
}

# 3. Enable ARR Proxy
Write-Host "`n[3/5] Enabling ARR Proxy..." -ForegroundColor Yellow
try {
    Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "enabled" -Value "True"
    Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "preserveHostHeader" -Value "True"
    Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "reverseRewriteHostInResponseHeaders" -Value "False"
    Write-Host "ARR Proxy enabled" -ForegroundColor Green
} catch {
    Write-Host "Could not enable ARR Proxy: $_" -ForegroundColor Red
    Write-Host "Make sure ARR is installed first" -ForegroundColor Yellow
}

# 4. Configure server variables
Write-Host "`n[4/5] Configuring allowed server variables..." -ForegroundColor Yellow
$variables = @(
    "HTTP_X_FORWARDED_FOR",
    "HTTP_X_FORWARDED_PROTO", 
    "HTTP_X_FORWARDED_HOST",
    "HTTP_SEC_WEBSOCKET_EXTENSIONS"
)

foreach ($var in $variables) {
    try {
        $existing = Get-WebConfiguration -Filter "system.webServer/rewrite/allowedServerVariables/add[@name='$var']" -PSPath 'MACHINE/WEBROOT/APPHOST'
        if ($null -eq $existing) {
            Add-WebConfiguration -Filter "system.webServer/rewrite/allowedServerVariables" -PSPath 'MACHINE/WEBROOT/APPHOST' -Value @{name=$var}
            Write-Host "Added server variable: $var" -ForegroundColor Green
        } else {
            Write-Host "Server variable already exists: $var" -ForegroundColor Gray
        }
    } catch {
        Write-Host "Could not add $var : $_" -ForegroundColor Yellow
    }
}

# 5. Open firewall port
Write-Host "`n[5/5] Checking firewall rules for port 8080..." -ForegroundColor Yellow
$firewallRule = Get-NetFirewallRule -DisplayName "Java App Port 8080" -ErrorAction SilentlyContinue
if ($null -eq $firewallRule) {
    New-NetFirewallRule -DisplayName "Java App Port 8080" -Direction Inbound -LocalPort 8080 -Protocol TCP -Action Allow
    Write-Host "Firewall rule created for port 8080" -ForegroundColor Green
} else {
    Write-Host "Firewall rule already exists for port 8080" -ForegroundColor Green
}

# 6. Restart IIS
Write-Host "`n[6/5] Restarting IIS..." -ForegroundColor Yellow
iisreset /restart
Write-Host "IIS restarted" -ForegroundColor Green

Write-Host "`n=== Configuration Complete ===" -ForegroundColor Cyan
Write-Host "`nNext steps:" -ForegroundColor Yellow
Write-Host "1. Ensure your Java app is running on port 8080" -ForegroundColor White
Write-Host "2. Check Azure NSG allows inbound HTTPS (443) traffic" -ForegroundColor White
Write-Host "3. Test WebSocket: wss://gcch-js-test-nk.eastus.cloudapp.azure.com/websocket/logs" -ForegroundColor White
Write-Host "`nIf ARR was not installed, download from:" -ForegroundColor Yellow
Write-Host "https://www.iis.net/downloads/microsoft/application-request-routing" -ForegroundColor Cyan
